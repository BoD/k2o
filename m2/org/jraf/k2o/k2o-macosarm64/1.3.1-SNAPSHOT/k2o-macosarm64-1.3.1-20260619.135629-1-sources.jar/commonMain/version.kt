// Generated file. Do not edit!
package org.jraf.k2o
import kotlin.jvm.JvmField
@JvmField
val VERSION = "1.3.1-SNAPSHOT"
