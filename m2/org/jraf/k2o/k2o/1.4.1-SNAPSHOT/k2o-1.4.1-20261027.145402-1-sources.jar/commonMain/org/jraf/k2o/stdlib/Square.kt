/*
 * This source is part of the
 *      _____  ___   ____
 *  __ / / _ \/ _ | / __/___  _______ _
 * / // / , _/ __ |/ _/_/ _ \/ __/ _ `/
 * \___/_/|_/_/ |_/_/ (_)___/_/  \_, /
 *                              /___/
 * repository.
 *
 * Copyright (C) 2025-present Benoit 'BoD' Lubek (BoD@JRAF.org)
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.jraf.k2o.stdlib

import androidx.compose.runtime.Composable
import org.jraf.k2o.dsl.Line
import org.jraf.k2o.units.Length

/**
 * Creates a 2D [square](https://en.wikibooks.org/wiki/OpenSCAD_User_Manual/2D_Primitives#square) (or rectangle).
 *
 * @param width The size along the X axis.
 * @param height The size along the Y axis. Defaults to [width], producing a square.
 * @param center When `false` (the default), the square is placed in the first quadrant, with one corner at the
 * origin. When `true`, it is centered on the origin.
 */
@Composable
fun Square(
  width: Length,
  height: Length = width,
  center: Boolean = false,
) {
  if (center) {
    Line("square(${Vect(width, height)}, center = true);")
  } else {
    Line("square(${Vect(width, height)});")
  }
}
