/*
 * This source is part of the
 *      _____  ___   ____
 *  __ / / _ \/ _ | / __/___  _______ _
 * / // / , _/ __ |/ _/_/ _ \/ __/ _ `/
 * \___/_/|_/_/ |_/_/ (_)___/_/  \_, /
 *                              /___/
 * repository.
 *
 * Copyright (C) 2026-present Benoit 'BoD' Lubek (BoD@JRAF.org)
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.jraf.k2o.units

internal operator fun Number.times(other: Number): Number = when (this) {
  is Byte -> when (other) {
    is Byte -> this * other
    is Short -> this * other
    is Int -> this * other
    is Long -> this * other
    is Float -> this * other
    is Double -> this * other
    else -> throw IllegalArgumentException("Unsupported number type: ${other::class}")
  }

  is Short -> when (other) {
    is Byte -> this * other
    is Short -> this * other
    is Int -> this * other
    is Long -> this * other
    is Float -> this * other
    is Double -> this * other
    else -> throw IllegalArgumentException("Unsupported number type: ${other::class}")
  }

  is Int -> when (other) {
    is Byte -> this * other
    is Short -> this * other
    is Int -> this * other
    is Long -> this * other
    is Float -> this * other
    is Double -> this * other
    else -> throw IllegalArgumentException("Unsupported number type: ${other::class}")
  }

  is Long -> when (other) {
    is Byte -> this * other
    is Short -> this * other
    is Int -> this * other
    is Long -> this * other
    is Float -> this * other
    is Double -> this * other
    else -> throw IllegalArgumentException("Unsupported number type: ${other::class}")
  }

  is Float -> when (other) {
    is Byte -> this * other
    is Short -> this * other
    is Int -> this * other
    is Long -> this * other
    is Float -> this * other
    is Double -> this * other
    else -> throw IllegalArgumentException("Unsupported number type: ${other::class}")
  }

  is Double -> when (other) {
    is Byte -> this * other
    is Short -> this * other
    is Int -> this * other
    is Long -> this * other
    is Float -> this * other
    is Double -> this * other
    else -> throw IllegalArgumentException("Unsupported number type: ${other::class}")
  }

  else -> throw IllegalArgumentException("Unsupported number type: ${this::class}")
}

internal operator fun Number.div(other: Number): Number = when (this) {
  is Byte -> when (other) {
    is Byte -> this / other
    is Short -> this / other
    is Int -> this / other
    is Long -> this / other
    is Float -> this / other
    is Double -> this / other
    else -> throw IllegalArgumentException("Unsupported number type: ${other::class}")
  }

  is Short -> when (other) {
    is Byte -> this / other
    is Short -> this / other
    is Int -> this / other
    is Long -> this / other
    is Float -> this / other
    is Double -> this / other
    else -> throw IllegalArgumentException("Unsupported number type: ${other::class}")
  }

  is Int -> when (other) {
    is Byte -> this / other
    is Short -> this / other
    is Int -> this / other
    is Long -> this / other
    is Float -> this / other
    is Double -> this / other
    else -> throw IllegalArgumentException("Unsupported number type: ${other::class}")
  }

  is Long -> when (other) {
    is Byte -> this / other
    is Short -> this / other
    is Int -> this / other
    is Long -> this / other
    is Float -> this / other
    is Double -> this / other
    else -> throw IllegalArgumentException("Unsupported number type: ${other::class}")
  }

  is Float -> when (other) {
    is Byte -> this / other
    is Short -> this / other
    is Int -> this / other
    is Long -> this / other
    is Float -> this / other
    is Double -> this / other
    else -> throw IllegalArgumentException("Unsupported number type: ${other::class}")
  }

  is Double -> when (other) {
    is Byte -> this / other
    is Short -> this / other
    is Int -> this / other
    is Long -> this / other
    is Float -> this / other
    is Double -> this / other
    else -> throw IllegalArgumentException("Unsupported number type: ${other::class}")
  }

  else -> throw IllegalArgumentException("Unsupported number type: ${this::class}")
}

internal operator fun Number.rem(other: Number): Number = when (this) {
  is Byte -> when (other) {
    is Byte -> this % other
    is Short -> this % other
    is Int -> this % other
    is Long -> this % other
    is Float -> this % other
    is Double -> this % other
    else -> throw IllegalArgumentException("Unsupported number type: ${other::class}")
  }

  is Short -> when (other) {
    is Byte -> this % other
    is Short -> this % other
    is Int -> this % other
    is Long -> this % other
    is Float -> this % other
    is Double -> this % other
    else -> throw IllegalArgumentException("Unsupported number type: ${other::class}")
  }

  is Int -> when (other) {
    is Byte -> this % other
    is Short -> this % other
    is Int -> this % other
    is Long -> this % other
    is Float -> this % other
    is Double -> this % other
    else -> throw IllegalArgumentException("Unsupported number type: ${other::class}")
  }

  is Long -> when (other) {
    is Byte -> this % other
    is Short -> this % other
    is Int -> this % other
    is Long -> this % other
    is Float -> this % other
    is Double -> this % other
    else -> throw IllegalArgumentException("Unsupported number type: ${other::class}")
  }

  is Float -> when (other) {
    is Byte -> this % other
    is Short -> this % other
    is Int -> this % other
    is Long -> this % other
    is Float -> this % other
    is Double -> this % other
    else -> throw IllegalArgumentException("Unsupported number type: ${other::class}")
  }

  is Double -> when (other) {
    is Byte -> this % other
    is Short -> this % other
    is Int -> this % other
    is Long -> this % other
    is Float -> this % other
    is Double -> this % other
    else -> throw IllegalArgumentException("Unsupported number type: ${other::class}")
  }

  else -> throw IllegalArgumentException("Unsupported number type: ${this::class}")
}
