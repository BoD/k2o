// Generated file. Do not edit!
package org.jraf.k2o
import kotlin.jvm.JvmField
@JvmField
val VERSION = "1.1.1-SNAPSHOT"
