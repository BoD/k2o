// Generated file. Do not edit!
package org.jraf.k2o
import kotlin.jvm.JvmField
@JvmField
val VERSION = "1.2.2-SNAPSHOT"
